#include <stdio.h>
#include "colours.h"

void red(void)
{

  printf("\033[0;31m");

}

void green(void)
{
 
  printf("\033[1;32m");

}
