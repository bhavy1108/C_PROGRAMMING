
void red(void);

void green(void);
