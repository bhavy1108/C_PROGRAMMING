#ifndef LINES_H
#define LINES_H


int findBracketAndDisplay(char lines[][150],int numLines);

#endif