#ifndef BRACK
#define BRACK

int symbol_brac(char m);
int matching (char m , char n);
char openBrac (char m);
int balanced (LinkedList *listing , char sym , int counter);
int searching  (char **file, int l );

#endif