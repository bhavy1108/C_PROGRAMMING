typedef enum
{
    openRound = 20,
    closeRound = -19,
    openSquare = 10,
    closeSquare = -9,
     openCurly = 40,
     closeCurly = -39,
     openTri = 50,
     closeTri = -49

}brackType;

typedef struct {
    char type;
    int  position;
    brackType style;
}bracs;

typedef struct{
    void* data;
    bracs* bracket;
    struct linkedListNode* next;
    struct linkedListNode* prev;

}linkedListNode;

typedef struct {
    int size;
     linkedListNode* head;
     linkedListNode* tail;

}LinkedList;

typedef void fPrintNode( linkedListNode* node);
typedef void fFreeNode( linkedListNode* node);

static linkedListNode* creatingNode(void* data);
LinkedList* createLinkedList();
void insertFirst(LinkedList* listing , void* entry);
void* removeFirst (LinkedList* listing);
void insertLast(LinkedList* listing , void* entry);
void* removeLast (LinkedList* listing);
void printLinkedList (LinkedList* listing , fPrintNode funcPointer);

void freeList (LinkedList* listing, fFreeNode functPointer);
