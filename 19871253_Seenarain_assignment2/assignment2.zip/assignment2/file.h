#ifndef FILE_H
#define FILE_H

int read(char* file, char lines[][150] );

#endif