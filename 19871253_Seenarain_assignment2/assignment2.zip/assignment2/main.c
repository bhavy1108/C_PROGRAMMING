#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "file.h"
#include "match.h"
#include "newSleep.h"
#include "lines.h"

int main(int argc,  char**argv)
{
      
      char lines[50][150];
     int numLines = 0;
     

    if(argc!=2)
	{
		printf("Arguments are missing!!\n");
	}
    else
    {
        numLines = read(argv[1],lines );

       /* for (i=0; i < numLines; i++)
        {
            for (j=0; j< strlen(lines[i]); j++)
             {*/
               /* printf("%c",lines[i][j]);*/
            findBracketAndDisplay(lines,numLines);
             
        
    }
    return 0;   
    
}

