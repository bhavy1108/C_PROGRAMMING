#ifndef STRUCTBRACK_H
#define STRUCTBRACK_H

typedef enum
{
    openRound = 20,
    closeRound = -19,
    openSquare = 10,
    closeSquare = -9,
     openCurly = 40,
     closeCurly = -39,
     openTri = 50,
     closeTri = -49

}brackType;

#endif